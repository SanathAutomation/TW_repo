import time

from selenium.webdriver.common.by import By
class ResultsPageClass:
    search_result_Xpath = "//div[@id='content']/h2[contains(text(),'Search Results')]"
    promoCodeUsed_Xpath = "//div[@id='content']/p[@class='promo_code']"
    departing_dropdown_Xpath = "//select[@id='departing']"
    search_button_Xpath = "//input[@value='Search']"







    def __init__(self,driver):
        self.driver = driver

    def searchResult(self):
        self.driver.find_element(By.XPATH,self.search_result_Xpath).is_displayed()



















