import time

from selenium.webdriver.common.by import By
class HomePageClass:
    mars_Air_Xpath = "(//*[contains(text(),' MarsAir')])[1]"
    departing_dropdown_Xpath = "//select[@id='departing']"
    search_button_Xpath = "//input[@value='Search']"
    promotional_code = "//input[@name='promotional_code']"







    def __init__(self,driver):
        self.driver = driver

    def marsAirImage(self):
        self.driver.find_element(By.XPATH,self.mars_Air_Xpath).click()

    def departing_dropdown(self):
        self.driver.find_element(By.XPATH,self.departing_dropdown_Xpath)

    def searchButton(self):
        self.driver.find_element(By.XPATH,self.search_button_Xpath).click()

    def promoCode(self,code):
        self.driver.find_element(By.XPATH,self.promotional_code).send_keys(code)




















