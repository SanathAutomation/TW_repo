import configparser

config = configparser.RawConfigParser()
config.read(".\\Configurations\\config.ini")

class ReadConfig:
    @staticmethod
    def getApplicationURL():
        url = config.get('common info','base_url')
        return url

    @staticmethod
    def getusername():
        username = config.get('common info', 'user_name')
        return username

    @staticmethod
    def getpassword():
        password = config.get('common info', 'pass_word')
        return password

    @staticmethod
    def get_ticketConfirmation():
        ticket = config.get('common info', 'confirm_msg')
        return ticket

    @staticmethod
    def getPromoCode():
        promoCode = config.get('common info', 'promotion_code')
        return promoCode

    @staticmethod
    def getPromoCodeMessage():
        promoCodemsg = config.get('common info', 'promotion_code_msg')
        return promoCodemsg

    @staticmethod
    def getInvalidPromoCode():
        invalidpromoCode = config.get('common info', 'invalid_promotion_code')
        return invalidpromoCode

    @staticmethod
    def getSeatUnavailableMsg():
        unavailableMsg = config.get('common info', 'seat_unavailable_msg')
        return unavailableMsg







