import time
from pageObjects.HomePage import HomePageClass
from pageObjects.ResultsPage import ResultsPageClass
from utilities.readProperties import ReadConfig
from utilities.customLogger import LogGen
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By

class Test_001_Login:
    base_url = ReadConfig.getApplicationURL()
    username= ReadConfig.getusername()
    password = ReadConfig.getpassword()
    cnf_message = ReadConfig.get_ticketConfirmation()
    promotional_message = ReadConfig.getPromoCodeMessage()
    logger = LogGen.loggen()
    promo_code = ReadConfig.getPromoCode()
    invalid_promo_code = ReadConfig.getInvalidPromoCode()
    seatNotAvailableMsg = ReadConfig.getSeatUnavailableMsg()

    def test_homePageTitle(self,setup):
        self.logger.info("*********Test Case 01 started************ ")
        self.driver = setup
        self.driver.get(self.base_url)
        time.sleep(2)
        self.driver.refresh()
        act_title = self.driver.title
        print(act_title)
        if act_title=="Mars Airlines: Home":
            assert True
        else:
            assert False
        self.driver.close()

    def test_BookingConfirm(self,setup):
        self.logger.info("*********Test Case 02 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        time.sleep(2)
        act_title=self.driver.title
        print(act_title)
        self.logger.warning("******Title is being verified**********")
        if act_title == "Mars Airlines: Home" :
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"test_loginTitle.png")
            assert False
        self.logger.info("*********Title is verified in login page************")
        time.sleep(2)
        self.homepg = HomePageClass(self.driver)
        self.homepg.marsAirImage()
        # dd = self.homepg.departing_dropdown()
        # Selecting from dropdown using Select class
        select = Select(self.driver.find_element(By.XPATH,"//select[@id='departing']"))
        #Getting the values from dropdown
        options = select.options
        values = [option.get_attribute("value") for option in options]
        print("Dropdown values are " , values)

        select.select_by_value("0")
        time.sleep(2)
        print("July selected from Departing dropdown")
        select1 = Select(self.driver.find_element(By.XPATH,"//select[@id='returning']"))
        select1.select_by_value("5")
        time.sleep(2)
        print("December (Two years from now) selected from returning dropdown")
        self.homepg.searchButton()
        time.sleep(2)
        self.respg = ResultsPageClass(self.driver)
        assert self.driver.find_element(By.XPATH,"//div[@id='content']/h2[contains(text(),'Search Results')]").is_displayed()
        confirmation = self.driver.find_element(By.XPATH,"//div[@id='content']/p[contains(text(),'Call now on 0800 MARSAIR to book!')]").text
        print(confirmation)
        if confirmation == self.cnf_message :
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"booking_confirmation.png")
            assert False
        self.driver.close()

    def test_BookingConfirmViaPromo_Code(self, setup):
        self.logger.info("*********Test Case 03 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        time.sleep(2)
        act_title = self.driver.title
        print(act_title)
        self.logger.warning("******Title is being verified**********")
        if act_title == "Mars Airlines: Home":
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
            assert False
        self.logger.info("*********Title is verified in login page************")
        time.sleep(2)
        self.homepg = HomePageClass(self.driver)
        self.homepg.marsAirImage()
        # dd = self.homepg.departing_dropdown()
        # Selecting from dropdown using Select class
        select = Select(self.driver.find_element(By.XPATH, "//select[@id='departing']"))
        select.select_by_value("0")
        time.sleep(2)
        print("July selected from Departing dropdown")
        select1 = Select(self.driver.find_element(By.XPATH, "//select[@id='returning']"))
        select1.select_by_value("5")
        time.sleep(2)
        print("December (Two years from now) selected from returning dropdown")
        self.homepg.promoCode(self.promo_code)
        self.homepg.searchButton()
        time.sleep(2)
        assert self.driver.find_element(By.XPATH,"//div[@id='content']/h2[contains(text(),'Search Results')]").is_displayed()
        promo_message = self.driver.find_element(By.XPATH,"//div[@id='content']/p[@class='promo_code']").text
        print(promo_message)
        assert promo_message == f"Promotional code {self.promo_code} used: 30% discount!"
        #{int(self.promo_code[0])}
        if promo_message == self.promotional_message:
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "promoCode_confirmation.png")
            assert False
        self.driver.close()

    def test_BookingConfirmVia_InvalidPromo_Code(self, setup):
        self.logger.info("*********Test Case 04 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        time.sleep(2)
        act_title = self.driver.title
        print(act_title)
        self.logger.warning("******Title is being verified**********")
        if act_title == "Mars Airlines: Home":
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
            assert False
        self.logger.info("*********Title is verified in login page************")
        time.sleep(2)
        self.homepg = HomePageClass(self.driver)
        self.homepg.marsAirImage()
        # dd = self.homepg.departing_dropdown()
        # Selecting from dropdown using Select class
        select = Select(self.driver.find_element(By.XPATH, "//select[@id='departing']"))
        select.select_by_value("0")
        time.sleep(2)
        print("July selected from Departing dropdown")
        select1 = Select(self.driver.find_element(By.XPATH, "//select[@id='returning']"))
        select1.select_by_value("5")
        time.sleep(2)
        print("December (Two years from now) selected from returning dropdown")
        self.homepg.promoCode(self.invalid_promo_code)
        self.homepg.searchButton()
        assert self.driver.find_element(By.XPATH,"//div[@id='content']/h2[contains(text(),'Search Results')]").is_displayed()
        Invalid_promo_message = self.driver.find_element(By.XPATH,"//div[@id='content']/p[@class='promo_code']").text
        print(Invalid_promo_message)
        time.sleep(2)
        assert Invalid_promo_message == f"Sorry, code {self.invalid_promo_code} is not valid"
        self.driver.close()

    def test_BookingWithInvalidDates(self, setup):
        self.logger.info("*********Test Case 05 started************")
        self.driver = setup
        self.driver.get(self.base_url)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        time.sleep(2)
        act_title = self.driver.title
        print(act_title)
        self.logger.warning("******Title is being verified**********")
        if act_title == "Mars Airlines: Home":
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\" + "test_loginTitle.png")
            assert False
        self.logger.info("*********Title is verified in login page************")
        time.sleep(2)
        self.homepg = HomePageClass(self.driver)
        self.homepg.marsAirImage()
        # dd = self.homepg.departing_dropdown()
        # Selecting from dropdown using Select class
        select = Select(self.driver.find_element(By.XPATH, "//select[@id='departing']"))
        select.select_by_value("0")
        time.sleep(2)
        print("July selected from Departing dropdown")
        select1 = Select(self.driver.find_element(By.XPATH, "//select[@id='returning']"))
        select1.select_by_value("4")
        time.sleep(2)
        print("July (Two Years from now) selected from returning dropdown")
        self.homepg.searchButton()
        assert self.driver.find_element(By.XPATH,"//div[@id='content']/h2[contains(text(),'Search Results')]").is_displayed()
        seat_unAvailable_msg = self.driver.find_element(By.XPATH,"//div[@id='content']/p[contains(text(),'Sorry')]").text
        print(seat_unAvailable_msg)
        self.logger.info("****Seat Unavailable******")
        #assert seat_unAvailable_msg == "Sorry, there are no more seats available."
        if seat_unAvailable_msg == self.seatNotAvailableMsg :
            assert True
        else:
            self.driver.save_screenshot(".\\Screenshots\\"+"test_seatUnavailable.png")
            assert False
        self.driver.quit()